/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, ElementRef } from '@angular/core';
/**
 * `<ps-sharer>` ou `<ps-sharer-matte-dark>`
 *
 * Componente de compartilhamento (share) dos links de mídias sociais.
 */
export declare class PsSharerComponent implements OnInit {
    private _elementRef;
    /** Parâmetro usado para definir a url de compartilhamento. */
    _type: string;
    /** Texto que será compartilhado. */
    _text?: string;
    /** Hashtags que serão compartilhadas. */
    _hashtags?: string;
    /** Perfil do site de mídia social. */
    _profile?: string;
    /** Título que será usado no post de compartilhamento. */
    _title?: string;
    /** Variável que conterá a classe css para a cor de fundo matte dark. */
    _isMatteDarkCSS?: string;
    /** Variável com o link de compartilhamento. */
    _url: string;
    constructor(_elementRef: ElementRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
}
