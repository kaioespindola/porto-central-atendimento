/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ViewContainerRef } from '@angular/core';
/**
 *
 * Configuração para abrir um modal com o serviço ModalService.
 */
export interface PsModalConfig {
    /** Referência ao componente que será criado no 'conteúdo' do modal.  */
    component: any;
    /** Container de Referência passada do componente que utiliza o service.  */
    viewContainerRef: ViewContainerRef;
    /** Dados passados como parâmetros ao componente que será criado no 'conteúdo' do modal.  */
    params?: any;
    /** Flag que desabilita o modal ser fechado clicando fora do mesmo. */
    modalbackdropstatic?: boolean;
    /** Flag que controla a ação de fechar o modal com a tecla esc. */
    modalkeyboarddisable?: boolean;
    /** Atributo de tamanho correspondente às classes css específicas do modal.  */
    size?: 'ps-modal-small-tablet' | 'ps-modal-small-desktop-sm' | 'ps-modal-small-desktop-lg' | 'ps-modal-medium-tablet' | 'ps-modal-medium-desktop-sm' | 'ps-modal-medium-desktop-lg' | 'ps-modal-large-tablet' | 'ps-modal-large-desktop-sm' | 'ps-modal-large-desktop-lg';
    /** Observer para executar quando o modal for fechado. */
    onHide?: any;
    /** Flag para indicar que o modal deve ser aberto / mostrado. */
    show?: boolean;
}
