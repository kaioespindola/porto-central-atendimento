/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { AfterViewInit, EventEmitter, Renderer2, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { Platform } from './../util/platform.service';
import { PsLoadingBarComponent } from './../ps-loading/ps-loading-bar.component';
import { PsModalLoadingConfig } from './ps-modal-loading.config';
import { Subject } from 'rxjs';
/**
 * ``
 *
 * Componente Modal Loading Reference.
 */
export declare class PsModalLoadingRefComponent implements OnChanges, AfterViewInit {
    private _renderer2;
    private _elementRef;
    private _platform;
    private psModalLoadingConfig?;
    /** Flag que indica se o modal está visível ou não.  */
    show?: boolean;
    /** Flag que desabilita o modal ser fechado clicando fora do mesmo. */
    backdrop: boolean;
    /** Flag que controla a ação de fechar o modal com a tecla esc. */
    keyboard: boolean;
    /** Flag que controla se deve aparecer o componente `ps-loading-bar`. */
    _bar: boolean;
    /** Evento disparado quando o modal é aberto (torna-se visível). */
    _modalOnShow?: EventEmitter<any>;
    /** Evento disparado quando o modal é fechado. */
    _modalOnHide?: EventEmitter<any>;
    /** Referência ao componente PsLoadingBar.  */
    psLoadingBar: PsLoadingBarComponent;
    /** Id único para o modal.  */
    _modalId: string;
    /** Flag que controla se o modal está aberto ou fechado. */
    _isOpen?: boolean;
    /** Guarda o valor da propriedade display do modal. */
    _display?: string;
    /** Evento disparado quando o modal é fechado. */
    modalonhideObservable: Subject<any>;
    /** Objeto retornado quando o modal é fechado. */
    modalonhide: any;
    /** Classe CSS adicionada e removida do body. */
    blackdropVisibleCSS: string;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform, psModalLoadingConfig?: PsModalLoadingConfig);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnChanges(changes: SimpleChanges): void;
    /** Método que abre o modal. Geralmente, chamado de algum evento de outro componente. */
    open($event: any): void;
    /** Método que fecha o modal. */
    close(): void;
    onkeyup(ev: KeyboardEvent): void;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
    /**
   * Configura a propriedade overflow do body adicionando e removendo uma classe CSS.
   * @param addCSS Flag que indica se é para adicionar ou remove a classe.
   */
    private _setBodyOverflow;
    /**
     * Adiciona uma div específica no body para efeito de backdrop.
     * @param body HTMLElement representando o body.
     */
    private _addBackdropDivToBody;
    /**
     * Remove uma div específica no body para efeito de backdrop.
     * @param body HTMLElement representando o body.
     */
    private _removeBackdropDivToBody;
}
