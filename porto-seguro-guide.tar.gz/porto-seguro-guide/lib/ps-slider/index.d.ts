/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
export * from './ps-range-slider.component';
export * from './ps-slider.component';
export * from './ps-slider.module';
export * from './ps-slider.style';
