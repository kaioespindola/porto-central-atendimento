/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ElementRef } from '@angular/core';
/**
 * `<ps-loading-bar>`
 *
 * Componente Loading Bar (Horizontal).
 */
export declare class PsLoadingBarComponent {
    /** Parâmetro de entrada que define a cor de fundo do loading.  */
    _color?: 'white';
    /** Referência ElementRef do elemento container do spinner. */
    _psLoadingBarContainer: ElementRef;
    /** Referência ElementRef do spinner. */
    _psBarSpinner: ElementRef;
    /** Flag que indica se o loading está contido dentro de um componente ps-modal-loading.  */
    _icoLoadingModal?: boolean;
    constructor();
}
