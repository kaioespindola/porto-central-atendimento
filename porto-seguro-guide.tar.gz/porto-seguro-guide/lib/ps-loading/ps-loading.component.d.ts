/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, Renderer2, ElementRef, OnChanges } from '@angular/core';
/**
 * `<ps-loading>`
 *
 * Componente Loading (Carregamento).
 */
export declare class PsLoadingComponent implements OnChanges, OnInit {
    private _renderer2;
    private _elementRef;
    /** Parâmetro de entrada que define a cor de fundo do loading.  */
    _color?: string;
    /** Parâmetro de entrada que define a tamanho do loading.  */
    _size?: string;
    /** Flag que indica se o loading está aninhado dentro de um button para adicionar a classe ps-ico. */
    hasPsBtnFather: boolean;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnChanges(): void;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
    /**
     * Método que verifica se a classe CSS está incluída no elemento.
     * @param element Referência HTMLElement.
     * @param className Classe CSS para ser verificada.
     * @returns boolean true se conter a classe CSS, false caso contrário.
     */
    private _hasClass;
}
