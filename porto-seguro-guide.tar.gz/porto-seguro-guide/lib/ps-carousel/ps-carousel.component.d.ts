/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, TemplateRef, AfterViewInit, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { SwiperComponent, SwiperConfigInterface } from 'ngx-swiper-wrapper';
/**
 * `<ps-carousel>`
 *
 * Componente container do carrossel (slider de imagens, cards, etc.).
 * Baseado no componente 'ngx-swiper-wrapper': https://github.com/zefoy/ngx-swiper-wrapper
 */
export declare class PsCarouselComponent implements OnInit, AfterViewInit {
    private renderer2;
    private changeDetector;
    /** Setas de navegação. Seu uso é opcional. Se não quiser utilizar setas, basta setar a flag como false. */
    arrow: boolean;
    /** Bullets. Os itens são preenchidos automaticamente. É opcional, se não desejar utilizar os bullets basta setar a flag como false. */
    points: boolean;
    /** Item que será apresentado em primeiro. O valor padrão é 1.  */
    start: number;
    /** Intervalo em milisegundos para girar carrossel. O valor padrão é 5000 (igual a 5s). Utilize 0, para desabilitar o intervalo.  */
    interval: number;
    /** Habilita a quantidade de item que deve ser exibido em cada scroll.  */
    slidesToScroll: number;
    template: TemplateRef<any>;
    slidesToShow: number;
    /** Habilita ou não que o carrossel seja infinito, ou seja, quando chegar ao final retorne ao primeiro. O valor padrão é true. */
    loop: boolean;
    /** JSON utilizado para configuração do componente `ps-carousel`. */
    responsive: Array<any>;
    data: Array<any>;
    config: SwiperConfigInterface;
    private pagination;
    private navigation;
    componentRef?: SwiperComponent;
    constructor(renderer2: Renderer2, changeDetector: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    resize(event: any): void;
    private processResponsiveBreakpoints;
    private enableArrows;
}
