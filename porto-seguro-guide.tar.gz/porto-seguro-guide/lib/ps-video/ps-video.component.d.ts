/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, ElementRef } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
/**
 * `<ps-video>`
 *
 * Componente que define um container do vídeo.
 */
export declare class PsVideoComponent implements OnInit {
    private _elementRef;
    private domSanitizer;
    /** Título do item */
    title: string;
    /** Descrição do item.  */
    description: string;
    /** URL do item.  */
    url: any;
    /** true para carregar automaticamente, ou false não carregar de forma automática.  */
    autoplay: boolean;
    /** Imagem do item */
    thumb: string;
    /** É possível definir como medium ou large. O valor padrão é médio  */
    modalwidth: string;
    /** Id único para o modal.  */
    _modalId: string;
    /** Flag que controla se o modal está aberto ou fechado. */
    _isOpen?: boolean;
    /** Guarda o valor da propriedade display do modal. */
    _display?: string;
    psModalVideo: ElementRef;
    constructor(_elementRef: ElementRef, domSanitizer: DomSanitizer);
    ngOnInit(): void;
    /** Método que abre o modal. */
    openModalVideo(): void;
    /** Método que fecha o modal. */
    closeModalVideo(): void;
    /** Método que verifica se houve um clique fora do modal.  */
    closeOnClickedOutside($event: any): void;
    onkeyup(ev: KeyboardEvent): void;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
    /**
     * Ignorar URL de recurso de confiança de segurança.
     */
    private sanitizeURL;
    /**
     * Configura a propriedade overflow do body.
     * @param overflow Valor da propriedade.
     */
    private _setBodyOverflow;
}
