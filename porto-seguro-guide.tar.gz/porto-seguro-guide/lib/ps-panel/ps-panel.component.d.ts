/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { TemplateRef } from '@angular/core';
/**
 * `<ng-template ps-panel-head>`
 *
 * Diretiva que Define o título de um painel `<ps-panel>`. Seu uso é opcional.
 */
export declare class PsPanelHeadDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-panel-ctt>`
 *
 * Diretiva que corresponde ao conteúdo do painel `<ps-panel>`.
 */
export declare class PsPanelCttDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-panel-foot>`
 *
 * Diretiva que corresponde ao rodapé de um painel `<ps-panel>`. Seu uso é opcional.
 */
export declare class PsPanelFootDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
}
/**
 * `<ps-panel>`
 *
 * Componente que define o container de um painel.
 */
export declare class PsPanelComponent {
    /**
     * Especifica o tipo do painel.
     *
     * `ps-panel-success`: Define que o painel será de sucesso.
     *
     * `ps-panel-alert`: Define que o painel será de alerta.
     *
     * `ps-panel-error`: Define que o painel será de erro.
     */
    _type?: string;
    /** Define que o painel terá um recuo para um ícone.  */
    _icon?: string;
    /** Referência ao elemento que contém o 'cabeçalho' do painel.  */
    _psPanelHeadTpl?: PsPanelHeadDirective;
    /** Referência ao elemento que contém o 'conteúdo' do painel.  */
    _psPanelCttTpl: PsPanelCttDirective;
    /** Referência ao elemento que contém o 'rodapé' do painel.  */
    _psPanelFootTpl?: PsPanelFootDirective;
    constructor();
}
