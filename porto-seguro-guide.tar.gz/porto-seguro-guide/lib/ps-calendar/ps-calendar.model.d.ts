/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
export declare class PsCalendarModel {
    static setDefaultDate: boolean;
    static disableWeekends: boolean;
    static format: string;
    static i18n: {
        previousMonth: string;
        nextMonth: string;
        months: string[];
        weekdays: string[];
        weekdaysShort: string[];
    };
    static getDateFromStr(dateString: any): Date;
    static getFormattedDate(date: any): string;
    static getISOFormattedDate(dateString: any): string;
    static getISODateFromStr(dateString: any): Date;
    static paddingNumber(num: number): string | number;
}
