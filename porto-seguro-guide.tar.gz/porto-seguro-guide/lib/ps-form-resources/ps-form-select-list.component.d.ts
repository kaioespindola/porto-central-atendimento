/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { AfterContentInit, Renderer2, ElementRef, EventEmitter } from '@angular/core';
/** Objeto de evento emitido por PsFormSelectListComponent quando um item da lista é selecionado ou desmarcado. */
export declare class PsFormSelectListChange {
    /** Representa o valor da opção selecionada no <select>. */
    val: any;
    /** Representa o texto que é apresentado na opção selecionada. */
    txt: string;
    /** Representa o objeto DOM do <select>. */
    select: HTMLSelectElement;
    /** Representa o objeto DOM da opção selecionada na lista. */
    listSelectedItem: HTMLElement;
    constructor(
    /** Representa o valor da opção selecionada no <select>. */
    val: any, 
    /** Representa o texto que é apresentado na opção selecionada. */
    txt: string, 
    /** Representa o objeto DOM do <select>. */
    select: HTMLSelectElement, 
    /** Representa o objeto DOM da opção selecionada na lista. */
    listSelectedItem: HTMLElement);
}
/**
 * `<ps-form-select-list>`
 *
 * Componente que configura uma lista de seleção a partir de um select.
 */
export declare class PsFormSelectListComponent implements AfterContentInit {
    private _renderer2;
    private _elementRef;
    /** Id da lista (opcional).  */
    _selectlistID?: string;
    /** Evento disparado quando um item da lista é selecionado. */
    _selectcallback: EventEmitter<PsFormSelectListChange>;
    /** Referência ao elemento select (HTMLSelectElement) que será usado para criar a lista.  */
    private selectElement;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterContentInit(): void;
    /** Método que configura o select interno (tornando invísivel) e cria a lista (ul, li) a partir dele.  */
    renderSelectList(): void;
    /**
     * Método que regista eventos na lista e sincroniza com o select.
     * @param a Elemento de referência ao link contido dentro do li da lista (ul).
     * @param ul Elemento de referência da lista (ul).
     * @param selectList Elemento <select> contido dentro do componente.
     */
    private _bindClickEventHandler;
    /**
     * Método que retorna um array contento os valores dos options no select.
     * @param selectElement Referência do select contido dentro do componente.
     * @param addOnlyValue Flag para indicar se só os valores e não os textos dos options devem ser retornados.
     */
    private _getSelectValues2Array;
    /**
     * Método que testa se um elemento contém a propriedade especificada como parâmetro.
     * @param el Referência HTMLElement do elemento que deve ser testado.
     * @param selector Parâmetro para testar se o elemento possui.
     * @returns boolean.
     */
    private _is;
    /** Retorna uma referência HTMLElement do componente. */
    private _getElementHost;
}
