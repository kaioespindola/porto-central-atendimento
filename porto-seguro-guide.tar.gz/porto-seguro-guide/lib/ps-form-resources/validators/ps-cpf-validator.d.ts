/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Validator, AbstractControl, ValidatorFn } from '@angular/forms';
/**
 *
 * Validator customizado para CPF usado em formulários reativos Reactive Forms.
 */
export declare function PsCPFValidator(): ValidatorFn;
/**
 *
 * Diretiva de atributo pra validação de CPF usado em template-driven forms.
 */
export declare class PsCPFValidatorDirective implements Validator {
    cpf: string;
    validate(control: AbstractControl): {
        [key: string]: any;
    } | null;
}
