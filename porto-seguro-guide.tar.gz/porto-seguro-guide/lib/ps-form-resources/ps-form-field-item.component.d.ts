/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 *`<ps-form-field-item>`
 *
 *
 * Componente que adiciona o label correspondente para campos do tipo checkbox e radio.
 * É específico somente para estes dois casos pois a classe css não é a mesma.
 */
export declare class PsFormFieldItemComponent {
    /** Texto do label para campos checkbox.   */
    _labelCheckbox?: string;
    /** Texto do label para campos radio.   */
    _labelRadio?: string;
    constructor();
}
