/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, Renderer2, ElementRef } from '@angular/core';
/**
 *
 * Diretiva de atributo que configura um elemento textarea adicionando a respectiva classe css.
 */
export declare class PsFormTextAreaDirective implements OnInit {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /** Método hook do angular que adiciona a classe css ao elemento textarea.  */
    ngOnInit(): void;
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    private _getHostElement;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes;
}
