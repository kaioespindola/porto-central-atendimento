/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ElementRef } from '@angular/core';
import { FormValidate } from './../util/form-validate.service';
/**
 * Diretiva de atributo para remover caracteres inválidos em campos input.
 */
export declare class PsFrmCleanupDirective {
    private _elementRef;
    private _formValidate;
    /** Flag para indicar se números são permitidos ou devem ser removidos.  */
    _allowNumbers: boolean;
    constructor(_elementRef: ElementRef, _formValidate: FormValidate);
    /** Método listener executado no evento blur.  */
    blur(event: Event): void;
    /** Método listener executado no evento keyup.  */
    keyup(event: KeyboardEvent): void;
    /** Método que remove caracteres inválidos no campo input anotado com a diretiva.  */
    private _cleanUp;
    /** Retorna uma referência HTMLElement contendo a diretiva. */
    private _getHostElement;
}
