/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
/**
 *
 * Diretiva de atributo para configurar um campo do tipo checkbox.
 */
export declare class PsFormCheckboxDirective implements OnInit, AfterViewInit {
    private _renderer2;
    private _elementRef;
    /** Variável usada para guardar o valor do atributo name.  */
    private _name;
    /** Id único do campo.  */
    private _checkboxId;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
    /**
     * Método que adiciona no input o atributo type como checkbox, a classe css específica
     * e verifica se o elemento já possui um id. Caso contrário, especifica um gerado
     * automaticamente.
     */
    ngOnInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    /** Método que adiciona o valor do atributo 'for' do label correspondente ao campo. */
    private _addForValueInLabel;
    /** Método que retorna o label correspondente ao campo. */
    private _getLabelElement;
    /** Retorna uma referência do elemento HTMLElement que contém a diretiva. */
    private _getHostElement;
}
