/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ElementRef, EventEmitter, OnInit, ViewContainerRef, AfterViewInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
/**
 * `<ps-form-multiselect-object>`
 *
 * Componente que define o select no formato de multiselect podendo selecionar mais item em uma lista.
 */
export declare class PsFormMultiselectObjComponent implements OnInit, ControlValueAccessor, AfterViewInit {
    /** Propriedades  de entrada */
    _name: string;
    _val: Array<any>;
    _options: Array<any>;
    _optionText: string;
    _optionValue: string;
    _title: string;
    /** Evento de callback emitido quando o modal é fechado.  */
    _onselect: EventEmitter<any>;
    /** Variáveis de desenvolvimento */
    opts: Array<{
        label: string;
        value: any;
    }>;
    selectedOptions: Array<{
        label: string;
        value: any;
    }>;
    checkboxPrefix: string;
    /** Instância do modal */
    _modal: ViewContainerRef;
    /** Instância do conteúdo do modal para manipulação dos checkboxes */
    _checkboxesContainer: ElementRef;
    /** handlers para ngModel */
    onChange: any;
    onTouched: any;
    constructor();
    /** Método hook do angular. Instancia a variável de opções que serão apresentadas em tela.  */
    ngOnInit(): void;
    ngAfterViewInit(): void;
    /** handler para ngModel */
    /** handler para ngModel */
    value: any[];
    /** handler para ngModel */
    registerOnChange(fn: any): void;
    /** handler para ngModel */
    registerOnTouched(fn: any): void;
    /** handler para ngModel: devolvendo valor para a instância superior */
    writeValue(value: any): void;
    /** método de emissão do evento onselect */
    private _onSelectEmit;
    /** método global para uniformização do array com distruição entre label e value */
    private _getUniformedData;
    /** método para procura do objeto (label, value) para montagem do objeto */
    private _searchForData;
    /** método para uniformização do array com distruição entre label e value */
    private _processData;
    /** método para comparação entre objetos ou valores */
    private _compareObjects;
    /** método que remove um dos itens da lista */
    _removeItem(idx: any): void;
    /** método para verificar se um checkbox deve estar checado */
    _checkOptionIsChecked(val: any): boolean;
    /** método de callback ao fechar o modal para remontar o valor do ngModel */
    _reconfigureMultiselect(): void;
    getMultiSelectObject(): any;
    changeMultiselectObject(): void;
}
