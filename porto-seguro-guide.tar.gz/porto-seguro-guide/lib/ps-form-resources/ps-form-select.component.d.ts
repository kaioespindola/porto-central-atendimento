/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 * `<ps-form-select>`
 *
 *
 * Componente de suporte para listas select adicionando um 'container' com a classe css específica.
 */
export declare class PsFormSelectComponent {
    constructor();
}
