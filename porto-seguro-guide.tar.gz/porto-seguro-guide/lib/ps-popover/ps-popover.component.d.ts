/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, AfterViewInit, Renderer2, ElementRef, TemplateRef } from '@angular/core';
import { Platform } from './../util/platform.service';
/**
 * `<ng-template ps-popover-title>`
 *
 * Diretiva que corresponde ao 'título' de um componente `<ps-popover>`.
 */
export declare class PsPopoverTitleDirective {
    _elementRef: ElementRef;
    templateRef: TemplateRef<any>;
    constructor(_elementRef: ElementRef, templateRef: TemplateRef<any>);
}
/**
 * `<ng-template ps-popover-content>`
 *
 * Diretiva que corresponde ao 'conteúdo' de um componente `<ps-popover>`.
 */
export declare class PsPopoverContentDirective {
    _elementRef: ElementRef;
    templateRef: TemplateRef<any>;
    constructor(_elementRef: ElementRef, templateRef: TemplateRef<any>);
}
/**
 * `<ps-popover>`
 *
 * Componente que define um objeto como popover.
 * A apresentação é um popover branco com seta à esquerda.
 */
export declare class PsPopoverComponent implements OnInit, AfterViewInit {
    private _renderer2;
    private _elementRef;
    private _platform;
    /** Flag que indica se ele está visível ou não.  */
    _show?: boolean;
    /** Referência ao elemento que contém Título do popover.  */
    _popoverTitle?: PsPopoverTitleDirective;
    /** Referência ao elemento que contém conteúdo do popover.  */
    _popoverContent: PsPopoverContentDirective;
    /** Referência ao componente popover.  */
    _popoverElem: ElementRef;
    /** Id único do componente.  */
    _popoverId: string;
    /** Flag indicando se deve conter ícone de fechar.  */
    _hasCloseIcon: boolean;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, _platform: Platform);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    /** Mostra o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseover, focusin, etc.).  */
    open($event: any): void;
    /** Esconde o popover. Geralmente, deve ser chamada através de um callback de eventos (mouseout, focusout, etc.).  */
    close(): void;
    /** Calcula a posição do popover de forma semelhante ao tooltip.  */
    private _setPosition;
    /**
     * Método que retorna o pai do elemento passado como parâmetro (selecionado via seletor com js nativo).
     * @param elem Referência ao elemento.
     * @param selector Valor do seletor que é usado para se buscar o pai.
     * @returns Referência ao elemento pai ou null.
     */
    private _getParentByClassWithRecursion;
    /** Método que configura classe e altera a propriedade display do popover.  */
    private _showHidePopoverElem;
    /** Método que adiciona o bloco HTML de ícone para o popover.  */
    private _addIconToPopoverContainer;
    /**
     * Retorna os elementos filhos do popover usando seletor de classe css.
     * @param css Classe css usada para a busca.
     * @returns Os elementos filhos que contém a classe css especificada.
     */
    private _getChildElementByClassName;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostAttributes;
}
