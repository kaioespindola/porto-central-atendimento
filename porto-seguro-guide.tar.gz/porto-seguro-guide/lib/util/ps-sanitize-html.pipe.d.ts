/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { DomSanitizer } from '@angular/platform-browser';
import { SafeHtml } from '@angular/platform-browser';
import { PipeTransform } from '@angular/core';
/**
 *
 * Pipe usado quando se quer injetar html via binding [innerHTML] sem ser convertido em texto.
 *
 * ## Examples
 *
 * <p [innerHTML]="value | psSanitizeHTML"></p>
 */
export declare class PsSanitizeHTMLPipe implements PipeTransform {
    private sanitized;
    constructor(sanitized: DomSanitizer);
    /**
     * Utilizada a referência a um DomSanitizer para analisar o HTML e deixar as tags.
     * @param value HTML passado como parâmetro para o pipe.
     * @returns Referência a um SafeHtml contento o html válido para ser injetado no componente.
     */
    transform(value: any): SafeHtml;
}
