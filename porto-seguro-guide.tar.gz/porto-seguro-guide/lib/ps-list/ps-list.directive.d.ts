/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { Renderer2, ElementRef } from '@angular/core';
/**
 *
 * Diretiva que define uma lista.
 */
export declare class PsListDirective {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
}
/**
 * Diretiva que define uma lista com divisões.
 */
export declare class PsListGrpDirective {
    private _renderer2;
    private _elementRef;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef);
}
