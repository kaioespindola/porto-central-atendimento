/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, ViewContainerRef, ElementRef, Injector, TemplateRef, Type, ComponentFactoryResolver, Renderer2 } from '@angular/core';
/**
 * Diretiva interna usada como elemento seletor no componente PsTooltipComponent.
 */
export declare class PsTooltipCttDirective {
}
/**
 * Componente tooltip interno criado dinamicamente.
 */
export declare class PsTooltipComponent implements OnInit {
    private psTooltipConfig;
    /** Distância do componente no eixo horizontal em relação ao portview.  */
    left: number;
    /** Distância do componente no eixo vertical em relação ao portview.  */
    top: number;
    /** Posição que apareça o componente em relação ao seu elemento trigger.  */
    placement: string;
    /** Posição da seta no componente.  */
    arrow: string;
    /** O componente em si (foi feito desta forma para evitar usar elementRef e firstChild, etc.).  */
    private psTooltipCtt;
    constructor(psTooltipConfig: any);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /**
     * Método para posicionamento do tooltip e direção da seta.
     * @param hostEl HTMLElement contendo o componente tooltip.
     * @param targetEl HTMLElement que possui o tooltip e é registrado o evento.
     * @param positionStr Posição (top, bottom, right e lef).
     * @param appendToBody Anexa o componente tooltip criado ao body ao invés do container do targetEl.
     * @returns Posições top e left corrigidas.
     */
    private positionElements;
    /**
     * Método que calcula a posição e dimensões de um elemento.
     * @param nativeEl HTMLElement contendo o elemento.
     * @returns Posições (top e left) e dimenões (width, height) calculadas.
     */
    private position;
    /**
     * Método que retorna os valores de posições de um elemento pelo método getBoundingClientRect().
     * @param nativeEl HTMLElement contendo o elemento.
     * @returns Posições (top e left) e dimenões (width, height) calculadas.
     */
    private offset;
    /**
     * Método que retorna o valor de uma propriedade definida no atributo style do elemento.
     * @param nativeEl HTMLElement contendo o elemento.
     * @returns string contendo o valor do atributo style.
     */
    private getStyle;
    /**
     * Método que verifica se o elemento não está com a propriedade position: static definida no atributo style.
     * @param nativeEl HTMLElement contendo o elemento.
     * @returns Verdadeiro se conter a propriedade 'position' com valor 'static'.
     */
    private isStaticPositioned;
    /**
     * Método que retorna o pai de um elemento.
     * @param nativeEl HTMLElement contendo o elemento.
     * @returns HTMLElement | document do elemento nativeEl.
     */
    private parentOffsetEl;
}
/**
 *
 * Diretiva de atributo para abrir um tooltip no elemento assinalado.
 */
export declare class PsTooltipDirective {
    private _element;
    private _renderer;
    private _injector;
    private _resolver;
    private _viewContainerRef;
    /** Texto com o conteúdo do tooltip.  */
    content?: string | TemplateRef<any> | Type<any>;
    /** Texto do tooltip e também usado para definir o tooltip com alinhamento abaixo do objeto.  */
    contentBottom?: string | TemplateRef<any> | Type<any>;
    /** Texto do tooltip e também usado para definir o tooltip com alinhamento à esquerda do objeto.  */
    contentLeft?: string | TemplateRef<any> | Type<any>;
    /** Texto do tooltip e também usado para definir o tooltip com alinhamento à direita do objeto.  */
    contentRight?: string | TemplateRef<any> | Type<any>;
    /** Referência ao componente tooltip que será criado dinamicamente.  */
    private componentRef;
    constructor(_element: ElementRef, _renderer: Renderer2, _injector: Injector, _resolver: ComponentFactoryResolver, _viewContainerRef: ViewContainerRef);
    ngOnDestroy(): void;
    /** Método acionado pelos eventos focus e mouseenter que cria o tooltip. */
    create(): void;
    onBindings(): void;
    /**
     * Método que cria o conteúdo do tooltip e define sua posição através dos parâmetros @Input.
     * @param position Posição do tooltip.
     * @returns Array<Array<any>> contendo o conteúdo do tooltip.
     */
    generatePsTooltipContent(position: any): any[][];
}
