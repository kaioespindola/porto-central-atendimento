/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
/**
 * `<ps-notify-success>`, `<ps-notify-error>`, `<ps-notify-alert>`
 *
 * Componente de mensagens (notificações de sucesso, de alerta ou de erro).
 */
export declare class PsNotifyComponent implements OnInit, AfterViewInit {
    private _renderer2;
    private _elementRef;
    private psNotifyConfig?;
    /** (opcional) Duração em milisegundos da apresentação da notificação. O valor padrão é 5000.  */
    _duration?: number;
    /** Flag indicando se ela deverá aparecer ou não.  */
    _show?: boolean;
    /** Referência ao componente de notificação.  */
    _psNotifyContainer: ElementRef;
    /** Id único do componente.  */
    _notifyId: string;
    /** Classe css do componente.  */
    _notifyCSS: string;
    /** Variável interna para armazenar referência ao intervalo de visibilidade da notificação.  */
    private _interval;
    constructor(_renderer2: Renderer2, _elementRef: ElementRef, psNotifyConfig?: any);
    ngOnInit(): void;
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngAfterViewInit(): void;
    onkeyup(ev: KeyboardEvent): void;
    /** Método que mostra a notificação. Geralmente, deve ser chamado de algum callback de eventos.  */
    open(): void;
    /** Método que esconde a notificação. Geralmente, deve ser chamado de algum callback de eventos.  */
    close(): void;
    /** Método que movimenta a notificação no eixo Y.  */
    private _translateY;
    /** Espera um intervalo de tempo antes de esconder a notificação.  */
    private _setTimeout;
    /** Retorna uma referência HTMLElement do componente. */
    private _getHostElement;
    /**
     * Método que adiciona uma propriedade css na de notificação.
     * @param property Propriedade css.
     * @param css Valor da propriedade.
     */
    private _addCssByProperty;
    /**
     * Verifica se o host element possui algum dos atributos.
     * @param attributes Array<string> de atributos.
     * @returns Verdadeiro se o host element possui algum dos atributos.
     */
    private _hasHostTagName;
    /** Método que retorna o elemento de notificação pelo seu atributo ID.  */
    private _getPsNotifyElem;
}
