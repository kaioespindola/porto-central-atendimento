/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { OnInit, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DatatableComponent } from '@swimlane/ngx-datatable';
/**
 * `<ps-datagrid>`
 *
 * Componente datagrid (tabela dinâmica com paginação e filtros de busca embutidos).
 * Baseado no componente 'ngx-datatable': https://github.com/swimlane/ngx-datatable
 * Documentação: https://swimlane.gitbook.io/ngx-datatable
 */
export declare class PsDatagridComponent implements OnInit {
    http: HttpClient;
    private _change;
    temp: any[];
    loadingIndicator: boolean;
    Math: any;
    table: DatatableComponent;
    /** (opcional) Define a quantidade de itens por página. O valor padrão é 20.  */
    pagesize: number;
    /** Define as colunas.  */
    columns: Array<any>;
    /** (opcional) Define se a tabela conterá campos para filtro e busca de itens. Valores aceitos são true e false. O valor padrão é false. */
    filtering: Boolean;
    /** (obrigatório) Define a origem dos dados.  */
    rows: Array<any>;
    /** (opcional) Define a origem dos dados.  */
    externalPaging: Boolean;
    /** (opcional) Define o sorting dos dados via server-side.  */
    externalSorting: Boolean;
    /** (obrigatório) Define a origem dos dados.  */
    totalElements: number;
    /** (opcional) Define o registro para o início da página  */
    offset: number;
    /** (opcional) Define o limite dos dados.  */
    limit: number;
    /** (opcional) Define a largura miníma das colunas. Essa opção indisponibiliza a responsividade. */
    minWidth?: number;
    /** (opcional) Define a largura máxima das colunas. Essa opção indisponibiliza a responsividade. */
    maxWidth: number;
    /** (opcional) Define o resize manual da coluna.  */
    resizeable: boolean;
    /** (opcional) Indica se a coluna do header deve mostrar o checkbox de seleção.  */
    checkboxable: boolean;
    /** (opcional) Indica se o checkbox deve aparecer na coluna do header.  */
    headerCheckboxable: boolean;
    /** (opcional) Função que define onde exibir os checkbox nas colunas.  */
    displayCheck: boolean;
    /** (opcional) Função que define quais devem ser selecionados no datagrid. */
    selected: boolean;
    /** (opcional) Define o modo de seleção da linha no datagrid.  */
    selectionType: boolean;
    /** (opcional) Define a ação a ser executada.  */
    _pagechange?: EventEmitter<any>;
    _pagecontent?: EventEmitter<any>;
    _onpagesort?: EventEmitter<any>;
    page: {
        totalElements: number;
        offset: number;
        limit: number;
    };
    parameters: {
        offset: number;
        sort: string;
        order: string;
        search: string;
        field: string;
        pagesize: number;
    };
    isPageChangeUsed: boolean;
    isPageUsed: boolean;
    isOnPageSortUsed: boolean;
    isRecalculate: boolean;
    private searchDelay;
    constructor(http: HttpClient, _change: ChangeDetectorRef);
    /** Hook do ciclo de vida. http://angular.io para mais informações. */
    ngOnInit(): void;
    /**
     * Método utilizado para realizar o filtro dos itens
     */
    updateFilter(value: any, field: any): void;
    /**
     * Método utilizado para setar a paginação
     */
    setPage(data: any): void;
    /**
    * Método utilizado para ordenar os items
    */
    onSort(data: any): void;
    /**
     * Método utilizado para realizar a troca de paginação
     */
    doPageChange($event: any): void;
    listener(event: any): void;
    recalculate(): void;
}
