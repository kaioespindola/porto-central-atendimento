/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
export * from './ps-badge.module';
export * from './ps-badge.component';
export * from './ps-badge-alert.component';
