/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
/**
 * `<ps-badge-alert>`
 *
 * Componente badge em vermelho (Contador).
 */
export declare class PsBadgeAlertComponent {
    /** Valor que deverá aparecer no contador.  */
    _value: number;
    /** Define o tipo como `ps-badge-alert`.  */
    _type: string;
    constructor();
}
