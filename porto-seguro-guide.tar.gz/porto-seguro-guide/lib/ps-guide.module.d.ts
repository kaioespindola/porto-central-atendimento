/**
 * @license
 * Copyright Porto Seguro All Rights Reserved.
 * @author
 * Porto Seguro https://www.portoseguro.com.br
 */
import { ModuleWithProviders } from '@angular/core';
export * from './ps-accordion/index';
export * from './ps-autocomplete/index';
export * from './ps-badge/index';
export * from './ps-btn/index';
export * from './ps-calendar/index';
export * from './ps-calendar-availability/index';
export * from './ps-card/index';
export * from './ps-carousel/index';
export * from './ps-chart/index';
export * from './ps-datagrid/index';
export * from './ps-dataview/index';
export * from './ps-form-resources/index';
export * from './ps-grid/index';
export * from './ps-ico/index';
export * from './ps-list/index';
export * from './ps-loading/index';
export * from './ps-menu/index';
export * from './ps-modal/index';
export * from './ps-notify/index';
export * from './ps-panel/index';
export * from './ps-popover/index';
export * from './ps-sharer/index';
export * from './ps-slider/index';
export * from './ps-table/index';
export * from './ps-tabs/index';
export * from './ps-title/index';
export * from './ps-tooltip/index';
export * from './ps-video/index';
export * from './ps-wizard/index';
export * from './util/index';
export declare class PsGuideModule {
    static forRoot(): ModuleWithProviders;
}
